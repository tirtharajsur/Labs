
public class FactorialUsingFactorial implements Runnable{

	@Override
	public void run() {
		int i;
		int fact=0;
		
		
		
	}
	
	

}
