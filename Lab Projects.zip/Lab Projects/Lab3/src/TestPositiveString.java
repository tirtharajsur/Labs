import java.util.Scanner;


public class TestPositiveString 
{
	public static boolean checkPositive(String s)
	{
		int flag = 0;
		for(int i=0;i<s.length()-1;i++)
		{
			if(s.charAt(i)>s.charAt(i+1))
			{
				flag=1;
				break;
			}
		}
		if(flag==0)
			return true;
		else
			return false;
		
	}

	public static void main(String[] args) 
	{
		String str;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String: ");
		str = sc.nextLine();
		str.toUpperCase();
		if(checkPositive(str))
			System.out.println(true);
		else
			System.out.println(false);
		
		sc.close();
	}
	
	
}
