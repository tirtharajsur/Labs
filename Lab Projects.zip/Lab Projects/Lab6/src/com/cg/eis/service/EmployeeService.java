package com.cg.eis.service;

import com.cg.eis.bean.*;
import com.cg.eis.exception.EmployeeException;

public interface EmployeeService 
{
	public abstract void addEmployeeDetails(int id,String name,double salary,Designations  designation, InsuranceSchemes insuranceScheme) throws EmployeeException;
	
	public abstract InsuranceSchemes showInsuranceSchemes(int id, double salary,Designations  designation);
	
	public abstract String dispEmployeeDetails(int id);
	
}
