package com.cg.eis.bean;

import com.cg.eis.exception.EmployeeException;

public class Employee 
{
	int id;
	String name;
	double salary;
	Designations designation;
	InsuranceSchemes insuranceSchemes;
	
	public Employee(int id, String name,double salary, Designations designation,
			InsuranceSchemes insuranceSchemes) throws EmployeeException {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		if(this.salary<3000)
			throw new EmployeeException();
		this.designation = designation;
		this.insuranceSchemes = insuranceSchemes;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary
				+ ", designation=" + designation + ", insuranceSchemes="
				+ insuranceSchemes + "]";
	}
}
