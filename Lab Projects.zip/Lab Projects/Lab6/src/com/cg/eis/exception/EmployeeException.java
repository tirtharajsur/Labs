package com.cg.eis.exception;

public class EmployeeException extends Exception 
{
	public EmployeeException()
	{
		System.out.println("Salary Below 3000!!!!");
	}

}
