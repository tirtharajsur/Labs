
public class BlankNameException extends Exception
{
	public BlankNameException()
	{
		System.out.println("Firstname or Lastname left Blank!");
	}

}
