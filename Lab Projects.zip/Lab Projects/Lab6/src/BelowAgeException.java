
public class BelowAgeException extends Exception 
{
	public BelowAgeException()
	{
		System.out.println("Person is Below Age!!");
	}

}
