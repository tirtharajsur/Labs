package Lab5_Default_Package;

public class CurrentAccount extends Account 
{
	double overDraftLimit;

	
	public CurrentAccount(long accNum,double balance,Person accHolder,double overDraft)
	{
		super(accNum,balance,accHolder);
		this.overDraftLimit=overDraft;
	}
	
	@Override
	public void withdraw(double m) throws OverDraftLimitSurpassed
	{
		if( m > overDraftLimit)
			balance = balance-m;
		else
			throw new OverDraftLimitSurpassed();
	}

}
