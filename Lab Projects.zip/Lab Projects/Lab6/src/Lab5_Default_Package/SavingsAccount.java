package Lab5_Default_Package;

public class SavingsAccount extends Account
{
	final double minBalance = 500;
	
	public SavingsAccount(long accNum,double balance,Person accHolder)
	{
		super(accNum,balance,accHolder);
	}
	
	@Override
	public void withdraw(double m) throws BalanceNotSufficientException
	{
		if(balance - m > minBalance)
			balance = balance - m;
		else
			throw new BalanceNotSufficientException();
	}

}
