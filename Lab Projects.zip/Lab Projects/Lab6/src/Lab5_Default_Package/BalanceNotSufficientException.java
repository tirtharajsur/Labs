package Lab5_Default_Package;

public class BalanceNotSufficientException extends Exception {

	BalanceNotSufficientException()
	{
		super();
		System.out.println("Cannot Withdraw due to insufficient Balance!");
	}
}
