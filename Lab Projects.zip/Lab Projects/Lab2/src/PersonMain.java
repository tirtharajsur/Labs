
public class PersonMain 
{

	public static void main(String[] args) 
	{
		Person p = new Person("Rahul","Guha",'M');
		System.out.println("Personal Details");
		System.out.println("-----------------");
		System.out.println("FirstName : " + p.getFirstName());
		System.out.println("LastName : " + p.getLastName());
		System.out.println("Gender : " + p.getGender());

	}

}
