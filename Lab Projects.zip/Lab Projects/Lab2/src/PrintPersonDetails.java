
public class PrintPersonDetails 
{

	public static void main(String[] args) 
	{
		System.out.println("Person Details:");
		System.out.println("---------------");
		String first = "Daipayan";
		String last = "Guha";
		char gender = 'M';
		int age = 22;
		double weight = 69.7;
		System.out.println("First Name: " + first);
		System.out.println("Last Name: " + last);
		System.out.println("Gender: " + gender);
		System.out.println("Age: " + age);
		System.out.println("Weight: " + weight);
		

	}

}
