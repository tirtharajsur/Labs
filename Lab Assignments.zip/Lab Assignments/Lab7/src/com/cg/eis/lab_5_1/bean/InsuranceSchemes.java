package com.cg.eis.lab_5_1.bean;
public enum InsuranceSchemes
{
	SchemeA,SchemeB,SchemeC,NoSchemes
}
