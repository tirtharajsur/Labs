
public class OverDraftLimitSurpassed extends Exception 
{
	public OverDraftLimitSurpassed()
	{
		System.out.println("Overdraft Limit Crossed!!!");
	}

}
