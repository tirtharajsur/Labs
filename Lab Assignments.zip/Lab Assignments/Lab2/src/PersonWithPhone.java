
public class PersonWithPhone
{
	private String firstName;
	private String lastName;
	private char gender;
	private String phoneNo;
	
	PersonWithPhone()
	{
		firstName = "";
		lastName = "";
		gender = '\0';
		phoneNo = "";
	}
	
	PersonWithPhone(String first, String last,char g,String ph)
	{
		firstName = first;
		lastName = last;
		gender = g;
		phoneNo = ph;
	}
	
	public void setFirstName(String fn)
	{
		firstName = fn;
	}
	
	public void setLastName(String ln)
	{
		lastName = ln;
	}
	
	public void setGender(char g)
	{
		gender = g;
	}
	
	public void setPhoneNo(String phNo)
	{
		phoneNo = phNo;
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public char getGender()
	{
		return gender;
	}
	
	public String getPhoneNo()
	{
		return phoneNo;
	}
	
	public void display()
	{
		System.out.println("Personal Details");
		System.out.println();
		System.out.println("-----------------");
		System.out.println("FirstName : " + firstName);
		System.out.println("LastName : " + lastName);
		System.out.println("Gender : " + gender);
		System.out.println("Phone Number : " + phoneNo);

	}

}
