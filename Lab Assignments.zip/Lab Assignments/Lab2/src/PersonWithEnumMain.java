
public class PersonWithEnumMain {

	public static void main(String[] args) {
		PersonWithEnum obj = new PersonWithEnum("Rohit","Sen",Gender.M,"9856223515");
		obj.display();

	}

}
