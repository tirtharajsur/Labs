enum Gender {
	Undefined,M,F;
}
public class PersonWithEnum
{
	private String firstName;
	private String lastName;
	private Gender gender;
	private String phoneNo;
	
	PersonWithEnum()
	{
		this.firstName = "";
		this.lastName = "";
		this.gender = Gender.Undefined;
		this.phoneNo = "";
	}
	
	PersonWithEnum(String first, String last,Gender g,String ph)
	{
		this.firstName = first;
		this.lastName = last;
		this.gender = g;
		this.phoneNo = ph;
	}
	
	public void setFirstName(String fn)
	{
		firstName = fn;
	}
	
	public void setLastName(String ln)
	{
		lastName = ln;
	}
	
	public void setGender(Gender ch)
	{
		gender = ch;
	}
	
	public void setPhoneNo(String phNo)
	{
		phoneNo = phNo;
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public Gender getGender()
	{
		return gender;
	}
	
	public String getPhoneNo()
	{
		return phoneNo;
	}
	
	public void display()
	{
		System.out.println("Personal Details");
		System.out.println("-----------------");
		System.out.println("FirstName : " + firstName);
		System.out.println("LastName : " + lastName);
		System.out.println("Gender : " + gender);
		System.out.println("Phone Number : " + phoneNo);

	}

}
