
public class PersonWithPhoneMain
{
	public static void main(String args[])
	{
		PersonWithPhone p1 = new PersonWithPhone("Sayan","Guha",'M',"9876543210");
		p1.display();
	}
}