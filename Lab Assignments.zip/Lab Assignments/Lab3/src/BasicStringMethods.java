import java.util.Scanner;


public class BasicStringMethods {
	
	public static void addStringToItself(String s)
	{
		s = s + s;

		System.out.println("Updated String: "+s);
	}
	
	public static void oddPosToUpper(String s)	
	{
		String s1 = "";
		String s2="";
		for(int i=0;i<s.length();i++)
		{
			
			if((i%2)!=0)
			{
				s1 = Character.toString(s.charAt(i));
				s2 += s1.toUpperCase();
			}
			else
				s2 += s.charAt(i);
		}
		System.out.println("Updated String: "+s2);
	}
	
	public static void oddPosToHash(String s)
	{
		for(int i=0;i<s.length();i++)
		{
			if((i+1)%2!=0)
			{
				s = s.replace(s.charAt(i), '#');
			}
		}
		System.out.println("Updated String: "+s);
	}
	
	public static void removeDuplicate(String s)
	{
		String s1="";
		int i,j;
		for( i=0;i<s.length();i++)
		{
			for(j=0;j<=i;j++)
			{
				if(s.charAt(i)==s.charAt(j))
					break;
			}
			if(j==i)
				s1+= s.charAt(i);
		}
		System.out.println("Updated String: "+s1);
	}
	

	public static void main(String[] args) {
		String str;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String: ");
		str = sc.nextLine();
		System.out.println(".........MENU...........");
		System.out.println("1.Append\n2.Replace with #\n3.Removal of duplicate\n4.Odd character to Upper Case\n5.Exit\n-----------");
		System.out.println("\n Enter your choice: ");
		int ch;

			ch= sc.nextInt();
			switch(ch)
			{
			case 1:
				addStringToItself(str);
				break;
			case 2:
				oddPosToHash(str);
				break;
			case 3:
				removeDuplicate(str);
				break;
			case 4:
				oddPosToUpper(str);
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			
			}
		
	
		
	}

}
