import java.util.Scanner;


public class UserIdValidator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter User ID: ");
		String uid = sc.nextLine();
		sc.close();
		
		if(ValidateID(uid))
		{
			System.out.println("Valid");
		}
		else
		{
			System.out.println("InValid");
		}

	}
	public static boolean ValidateID(String id)
	{
		return id.matches("^>{8,}_job$");
	}

}
