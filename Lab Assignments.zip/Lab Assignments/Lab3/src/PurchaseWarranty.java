import java.time.LocalDate;
import java.time.Period;
import java.util.*;

public class PurchaseWarranty {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Purchase Date in dd-mm-yyyy format: ");
		String s1 = sc.nextLine();
		s1 = s1+" ";
		int day1 = Integer.parseInt(s1.substring(0,2));
		int month1 = Integer.parseInt(s1.substring(3,5));
		int year1 = Integer.parseInt(s1.substring(6,10));
		LocalDate purchaseDate = LocalDate.of(year1,month1,day1);
		System.out.println(purchaseDate);
		
		System.out.println("Enter Warranty period:\nEnter Month: ");
		long mm = sc.nextLong();
		System.out.println("Enter Year: ");
		long yy=sc.nextLong();
		purchaseDate = purchaseDate.plusMonths(mm);
		purchaseDate = purchaseDate.plusYears(yy);
		System.out.println("Warranty expires on "+purchaseDate);
	}

}
