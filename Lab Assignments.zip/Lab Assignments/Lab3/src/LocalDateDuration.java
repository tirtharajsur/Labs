import java.time.LocalDate;
import java.time.Period;
import java.util.*;

public class LocalDateDuration {

	/*public LocalDate udate;
	public void setDate(String s)
	{
		s = s+" ";
		int dd = Integer.parseInt(s.substring(0,2));
		int mm = Integer.parseInt(s.substring(3,5));
		int yyyy = Integer.parseInt(s.substring(6,10));
		LocalDate udate = LocalDate.of(yyyy,mm,dd);
		System.out.println(udate);
		
		
	}*/
	
	
	public static void main(String[] args)
	{
		
		Scanner sc = new Scanner(System.in);
		
		//LocalDateDuration date1= new LocalDateDuration();
		System.out.println("Enter First Date in dd-mm-yyyy format: ");
		String s1 = sc.nextLine();
		s1 = s1+" ";
		int dd = Integer.parseInt(s1.substring(0,2));
		int mm = Integer.parseInt(s1.substring(3,5));
		int yyyy = Integer.parseInt(s1.substring(6,10));
		LocalDate u1date = LocalDate.of(yyyy,mm,dd);
		System.out.println(u1date);
		
		//date1.setDate(s1);
		
		//LocalDateDuration date2= new LocalDateDuration();
		System.out.println("Enter Second Date in dd-mm-yyyy format: ");
		String s2 = sc.nextLine();
		s2 = s2+" ";
		int dd2 = Integer.parseInt(s2.substring(0,2));
		int mm2 = Integer.parseInt(s2.substring(3,5));
		int yyyy2 = Integer.parseInt(s2.substring(6,10));
		LocalDate u2date = LocalDate.of(yyyy2,mm2,dd2);
		System.out.println(u2date);
		//date2.setDate(s2);
		
		
		
		Period p = Period.between(/*date1.*/u1date,/*date2.*/u2date);
		System.out.println("Difference is: "+p.getYears()+" Years "+
				p.getMonths()+" Months"+
				p.getDays()+" Days");
		
		

	}

}
