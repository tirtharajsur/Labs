import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Scanner;


public class TimeZone {
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Time Zone from the folowing:\nAmerica/New_York,\n Europe/London,\n Asia/Tokyo,\n US/Pacific,\n Africa/Cairo,\n Australia/Sydney");
		String zone_id = sc.next();
		LocalDateTime dateTime = java.time.LocalDateTime.now(ZoneId.of(zone_id));
		System.out.println("The Local Date and Time of "+zone_id+" zone is "+dateTime);
	}

}
