import java.util.*;
public class AlphabeticalSortingOfStringsSet {

	public static void main(String[] args)
	{
		int i,j;
		System.out.println("Enter the Number of Strings: ");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		String str[] = new String[n];
		System.out.println("Enter the Strings: ");
		for(i=0;i<n;i++)
		{
			str[i]=sc.next();
		}
		for(i=0;i<str.length;i++)
		{
			for(j=0;j<(str.length-1);j++)
			{
				if(str[j].compareTo(str[j+1]) > 0)
				{
					String str1 = str[j];
					str[j]=str[j+1];
					str[j+1]=str1;
				}
			}
		}
		
		System.out.println("Printing the Strings in Alphabetical Order: ");
		if(str.length%2==0)
		{
			for(i=0;i<str.length/2;i++)
			{
				str[i] = str[i].toLowerCase();
				System.out.print(str[i]+" ");
			}
			for(i=str.length/2;i<str.length;i++)
			{
				str[i] = str[i].toUpperCase();
				System.out.print(str[i]+" ");
			}
		}
		else
		{
			for(i=0;i<str.length/2+1;i++)
			{
				str[i] = str[i].toLowerCase();
				System.out.print(str[i]+" ");
			}
			for(i=str.length/2+1;i<str.length;i++)
			{
				str[i] = str[i].toUpperCase();
				System.out.print(str[i]+" ");
			}
			
		}

	}

}
