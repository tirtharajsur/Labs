package com.cg.project.util;

import java.time.LocalDate;
import java.util.HashMap;

import com.cg.project.beans.Department;
import com.cg.project.beans.Employee;

public class EmployeeRepository {
	public static HashMap<Integer,Employee> employeeDetails = new HashMap<>();
	public static int EMPLOYEE_ID_COUNTER = 100;
	static {
		employeeDetails.put(101, new Employee("Pritam", "Chakraborty", "pritchat@gmail.com", "9874556233", LocalDate.of(2015,5,1),"Sn Analyst", 56000,111,
					new Department(11, "JEE",111)));
		employeeDetails.put(102, new Employee("Daipayan", "Guha", "daipayan@gmail.com", "9874696233", LocalDate.of(2016,9,2),"Jn Analyst", 46000,112,
				new Department(12, "BI",112)));
		employeeDetails.put(103, new Employee("Sayan", "Chakraborty", "sayan.sayan@gmail.com", "9666656233", LocalDate.of(2016,10,4),"Jn Analyst", 46000,113,
				new Department(13, "JEE",113)));
		employeeDetails.put(104, new Employee("Debojyoti", "Basu", "debu.basu@gmail.com", "9874512343", LocalDate.of(2015,2,15),"Sn Analyst", 56000,114,
				new Department(14, "BI",114)));
		employeeDetails.put(105, new Employee("Swastik", "Bhattacharya", "bhola@gmail.com", "9878888233", LocalDate.of(2018,5,25),"Jn Analyst", 46000,115,
				new Department(15, "JEE",115)));
	}
	public static int getEMPLOYEE_ID_COUNTER() {
		return ++EMPLOYEE_ID_COUNTER;
	}

}
