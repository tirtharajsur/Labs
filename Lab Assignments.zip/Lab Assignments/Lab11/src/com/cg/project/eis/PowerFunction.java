package com.cg.project.eis;
@FunctionalInterface
public interface PowerFunction {
	public double power(double  x,double  y);

}
