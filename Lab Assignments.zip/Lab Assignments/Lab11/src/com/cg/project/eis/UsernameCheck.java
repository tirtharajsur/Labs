package com.cg.project.eis;
@FunctionalInterface
public interface UsernameCheck {
	public boolean check(String username,String password);

}
