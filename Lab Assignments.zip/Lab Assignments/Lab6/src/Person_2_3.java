
public class Person_2_3 
{
	private String firstName;
	private String lastName;
	private char gender;
	
	Person_2_3()
	{
		firstName = "";
		lastName = "";
		gender = '\0';
	}
	
	Person_2_3(String firstName, String lastName,char gender) throws BlankNameException
	{
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		if(firstName.isEmpty() || lastName.isEmpty())
			throw new BlankNameException();
	}
	
	
		public void setFirstName(String fn) throws BlankNameException
		{
			if(firstName.isEmpty())
					throw new BlankNameException();
			firstName = fn;
		}
	
		
		public void setLastName(String ln) throws BlankNameException
		{
			if(lastName.isEmpty())
				throw new BlankNameException();
			lastName = ln;
		}
		
	
	
	public void setGender(char g)
	{
		gender = g;
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public char getGender()
	{
		return gender;
	}
	
}
