
public class Person_2_3_Main 
{

	public static void main(String[] args) throws BlankNameException 
	{
		
		Person_2_3 p =null;
		p = new Person_2_3("Rahul","Guha",'M');
		System.out.println("Personal Details");
		System.out.println("-----------------");
		System.out.println("FirstName : " + p.getFirstName());
		System.out.println("LastName : " + p.getLastName());
		System.out.println("Gender : " + p.getGender());

	}

}
