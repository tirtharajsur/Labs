
public class MainClass {

	public static void main(String[] args) {
		FileOperations.threadedFileCopy("D:\\source.txt","D:\\target.txt");
		System.out.println("File Copy Complete");

	}

}
