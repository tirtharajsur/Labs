
public class FactorialUsingThread{

	public static double fact(double n) {
		double fact =1;
		for(int i=2;i<=n;i++)
			fact*=i;
		return fact;
				
	}
	
	

}
